package yusuh.gulu.ntv

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button

class secondActivity : AppCompatActivity() {
    private val webView: WebView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        title = "NTV LIVE STREAM"
        val webView = findViewById<WebView>(R.id.webview)
        webView?. webViewClient = WebViewClient()
        webView?.loadUrl("https://www.ntv.co.ug/ug/ntv-live")
        val webSettings = webView.settings
        webSettings?.javaScriptEnabled = true
      }

    override fun onBackPressed() {
        super.onBackPressed()
        if (webView!!.canGoBack()){
            webView.goBack()

        }else{
            super.onBackPressed()

        }
    }

    }

